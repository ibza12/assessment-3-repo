﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx3
{
    internal class Program
    {
        static void Main(string[] args)
        {


            //Create a Menu driven interface here so a user can interact with your implementations

            //I.e. while(true){
            // print to user - "Select an option"
            // "1. Demo sort..."
            // "2. Add item for greedy algorithm... ect
            //}

            //You won't need to create either of the utils classes, both use static methods.

            //I.e. 
            //SortUtils.InsertSort();
            //GreedyUtils.GetGreedyManifesto();
        }
    }
}
